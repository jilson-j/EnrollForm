<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\enroll;
class EnrollController extends Controller
{
    public function index(){

    }
    public function enrollsave(Request $request){

      
        $test=enroll::where('email',$request->email)->first();
        if($test){
            return response()->json([ 'success'=> 'Email Already Exist!']);
        }
        else{
            $test=new enroll();
            $test->name=$request->name;
            $test->email=$request->email;
            $test->mobile_number=$request->mobile_number;
            $test->basic=$request->basic;
            $test->hra=$request->hra;
            $test->special=$request->special;
            $test->pf=$request->pf;
            $test->total=($request->basic+$request->hra+$request->special)-($request->pf);
            

            $test->save();
        }
       
        return response()->json([ 'success'=> 'Form is successfully submitted!']);

    }

    public function enrolllist(){
        $enrolllist=enroll::all();
        return view('enrolllist',compact('enrolllist'));
    }
    public function editenrolllist($id){
        $enrolllist=enroll::find($id);
        return view('edit_enrolllist',compact('enrolllist'));
    }


    public function update(Request $request,$id){

      
        $test=enroll::find($id);
  
            $test->name=$request->name;
            $test->email=$request->email;
            $test->mobile_number=$request->mobile_number;
            $test->basic=$request->basic;
            $test->hra=$request->hra;
            $test->special=$request->special;
            $test->pf=$request->pf;
            $test->total=($request->basic+$request->hra+$request->special)-($request->pf);
            

            $test->update();
            return response()->json([ 'success'=> 'Form is successfully Updated!']);
        }
       
        
        public function delete($id){
            $enrolllist=enroll::find($id)->delete();
           
            return redirect('/enroll-list')->with('success','Form Delete Successfully.'); 
        }
    
}
