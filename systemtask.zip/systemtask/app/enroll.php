<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class enroll extends Model
{
    //
}
