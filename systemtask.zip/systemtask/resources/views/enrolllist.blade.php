<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">

<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>
<style>
.note
{
    text-align: center;
    height: 80px;
    background: -webkit-linear-gradient(left, #0072ff, #8811c5);
    color: #fff;
    font-weight: bold;
    line-height: 80px;
}
.form-content
{
    padding: 5%;
    border: 1px solid #ced4da;
    margin-bottom: 2%;
}
.form-control{
    border-radius:1.5rem;
}
.btnSubmit
{
    border:none;
    border-radius:1.5rem;
    padding: 1%;
    width: 20%;
    cursor: pointer;
    background: #0062cc;
    color: #fff;
}
</style>


<div class="container register-form">
<br><br>
            <div class="form">
                <div class="note">
                    <p>Enroll List</p>
                </div>
                @if(session()->has('success'))
    <div class="alert alert-success">
        {{ session()->get('success') }}
    </div>
@endif
                <table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Mobile Number</th>
                <th>Basic</th>
                <th>HRA</th>
                <th>Special</th>
                <th>PF</th>
                <th>Total</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        @foreach($enrolllist as $enroll)
            <tr>
                <td> {{$enroll->name}}</td>
                <td>{{$enroll->email}}</td>
                <td>{{$enroll->mobile_number}}</td>
                <td>{{$enroll->basic}}</td>
                <td>{{$enroll->hra}}</td>
                <td>{{$enroll->special}}</td>
                <td>{{$enroll->pf}}</td>
                <td>{{$enroll->total}}</td>
               
                <td><a href="/edit/{{$enroll->id}}">edit<a>&nbsp;<a href="/delete/{{$enroll->id}}">delete<a></td>
            </tr>
          @endforeach
           
        </tbody>
        <tfoot>
           
        </tfoot>
    </table>

            </div>
        </div>
        
        <script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>